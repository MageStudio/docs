# Physics

Mage uses Ammo.js as physics engine