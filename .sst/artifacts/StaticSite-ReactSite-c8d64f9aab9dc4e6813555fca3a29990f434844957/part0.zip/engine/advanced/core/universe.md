# Universe

The Universe module is responsible for holding everything that is displayed within your level. It offers a number of methods you can use to search for Entities.

## Methods

#### get(name: String): Entity

#### getByUUID(uuid: String): Entity

#### getByTag(tag: String): Entity
