# Engine Documentation

Mage Engine is a Javascript game engine built on top of THREE and Ammojs. It features all you need to create fully interactive 3D application that can be distributed via web, ~desktop~ or ~mobile~.

The best way to get started is to begin reading the installation guide [here](/engine/getting-started/installing-mage-engine.md).